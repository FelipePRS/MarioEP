#ifndef MINIMIZA_H
#define MINIMIZA_H

typedef int bool;

typedef struct No {
	int 	estado;
	int 	simbolo;
	struct 	No* prox;
} No;

// List of adjacencies graph implementation.
typedef struct Grafo {
	No* 	comeco;
	int 	estado;
	bool	inicio;
	bool	aceitacao;
	bool 	visitado;
	bool 	finalizado;
} Grafo;

No* criarNo();
void iniciaGrafo(Grafo* g);
Grafo* novoGrafo(int estado);
bool existeLimite(Grafo* g, int from, int to, int simbolo);
int pesquisar(Grafo* g, int from, int simbolo);
bool adicionarLimite(Grafo* g, int from, int to, int simbolo);
Grafo* removerEstado(Grafo* g, int estado);
void iniciaVisitado(Grafo* g);
void iniciaFinalizado(Grafo* g);
void dfs(Grafo* g, int estado);
void inacessivel(Grafo** g, int inicio);
Grafo* inverso(Grafo* g);
void estadosInuteis(Grafo** g);
Grafo* equivalente(Grafo* g, int symbols);
void escreverAFD(Grafo* g, int symbols, FILE* file);

#endif




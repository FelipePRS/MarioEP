#include <stdio.h>
#include <stdlib.h>
#include "minimiza.h"
#define true 1
#define false 0

int main(int argc, char const *argv[]) {
	
	if(argc != 3) {		
		exit(1);
	}

	FILE *input = fopen(argv[1], "r");
	if (!input) {
		printf("Ocorreu um erro o arquivo nao foi encontrado\n");
		exit(1);
	}

	FILE* out = fopen(argv[2], "w");
	if(!out) {
		printf("Arquivo invalido\n");
		exit(1);
	}

	int estado, simbolos, inicio;
	
	fscanf(input, "%d", &estado);
	fscanf(input, "%d", &simbolos);
	fscanf(input, "%d", &inicio);

	Grafo* dfs = novoGrafo(estado);

	dfs[inicio].inicio = true;

	//Lendo os estados de aceitacao
	int i;
	
	for(i = 0; i < estado; i++) {
		fscanf(input, "%d", &dfs[i].aceitacao);
	}

	//Lendo os simbolos
	int j; int to;
	for(i = 0; i < estado; i++) {
		for (j = 0; j < simbolos; j++) {
			fscanf(input, "%d", &to);
			adicionarLimite(dfs, i, to, j);
		}
	}

	//Retirando os estados inacessiveis.
	inacessivel(&dfs, inicio);

	//Retirando os estados inuteis.
	estadosInuteis(&dfs);

	// Gerando o novo AFD
	escreverAFD(equivalente(dfs, simbolos), simbolos, out);

	fclose(input);
	fclose(out);

	return 0;
}

// Cria uma nova estrutura de no
No* criarNo(int estado, int simbolo, No* prox) {
	No* no = (No*) malloc(sizeof(No));
	no->estado = estado;
	no->simbolo = simbolo;
	no->prox = prox;
	return no;
}

// Inicializa o grafo
void iniciaGrafo(Grafo* g) {
	int i;
	for (i = 0; i < g->estado; i++) {
		g[i].comeco = NULL;
		g[i].inicio = false;
		g[i].aceitacao = false;
		g[i].visitado = false;
		g[i].finalizado = false;
	}
}

//Cria um novo grafo na memoria
Grafo* novoGrafo(int estado) {
	Grafo *g = (Grafo*) malloc(sizeof(Grafo) * estado);
	g->estado = estado;
	iniciaGrafo(g);
	return g;
}

//Procure um limite no grafo, usando 'from' como origem
//e 'to' como destino, com simbolo como seu peso.
bool existeLimite(Grafo* g, int from, int to, int simbolo) {
	No* n = g[from].comeco;
	while(n) {
		if(n->estado == to && n->simbolo == simbolo) {
			return true;
		}
		n = n->prox;
	}
	return false;
}

// Retorno o proximo estado
int pesquisar(Grafo* g, int from, int simbolo) {
	
	No* n = g[from].comeco;
	
	while(n) {
		
		if(n->simbolo == simbolo) {		
			return n->estado;
		}
		
		n = n->prox;
	}
	
	return -1;
}

//Insere um novo limine no grafo
bool adicionarLimite(Grafo* g, int from, int to, int simbolo) {
	
	if(from < 0 || to < 0 || simbolo < 0){
		return false;	
	} 
	
	if(existeLimite(g, from, to, simbolo)){
		return false;
	}
	 
	No* new = criarNo(to, simbolo, g[from].comeco);
	
	g[from].comeco = new;
	
	return true;
}

//Remove o estado no grafo e ordena
Grafo* removerEstado(Grafo* g, int estado) {
	
	printf("Removendo estado: %d\n", estado);
	
	if(g[estado].inicio){
		 return g;
	}
	
	Grafo* copiaGrafo = novoGrafo(g->estado - 1); int i;
	
	for (i = 0; i < g->estado; i++) {
	
		if(i == estado) continue;
	
		if(g[i].inicio) {
			if(i < estado) copiaGrafo[i].inicio = true;
			else copiaGrafo[i-1].inicio = true;
		}
		
		if(g[i].aceitacao) {
			if(i < estado) copiaGrafo[i].aceitacao = true;
			else copiaGrafo[i-1].aceitacao = true;
		}
		
		No* n = g[i].comeco;
		
		while(n) {
			
			if(n->estado != estado) {
				
				if(i < estado) {
					if(n->estado < estado) adicionarLimite(copiaGrafo, i, n->estado, n->simbolo);
					else adicionarLimite(copiaGrafo, i, n->estado-1, n->simbolo);
				} else {
					if(n->estado < estado) adicionarLimite(copiaGrafo, i-1, n->estado, n->simbolo);
					else adicionarLimite(copiaGrafo, i-1, n->estado-1, n->simbolo);
				}
			}
			
			if(i > estado && n->estado == estado) {
				adicionarLimite(copiaGrafo, i-1, i-1, n->simbolo);
			}
			
			n = n->prox;
		}
	}
	
	return copiaGrafo;
}

//Inicia tudo como nao visitado
void iniciaVisitado(Grafo* g){
		
	int i;
	
	for (i=0; i < g->estado; i++) {
		g[i].visitado = false;
	}
}

//Inincia tudo como nao finalizado
void iniciaFinalizado(Grafo* g) {
	int i;
	for (i = 0; i < g->estado; i++) {
		g[i].finalizado = false;
	}
}

//Esse metodo realiza a buscar em profundida no grafo
void dfs(Grafo* g, int estado) {
	
	g[estado].visitado = true;
	
	No* n = g[estado].comeco;
	
	while(n) {
		
		if(!g[n->estado].visitado){
			 dfs(g, n->estado);
		}
	
		n = n->prox;
	}
	
	g[estado].finalizado = true;
}


// Metodo para remover todos os estados inacessiveis
void inacessivel(Grafo** g, int inicio) {
	
	Grafo* grafo = *g;
	
	dfs(grafo, inicio);
	
	int i;
	
	for(i = 0; i < grafo->estado; i++) {
		
		if(!grafo[i].finalizado){
			*g = removerEstado(grafo, i);
		} 
	}
	
	iniciaFinalizado(*g);
	
	iniciaVisitado(*g);
}

//Retorna um grafo com todos os limites invertidos
Grafo* inverso(Grafo* g) {
	
	Grafo* r = novoGrafo(g->estado + 1);
	
	int i;
	
	for(i = 0; i < g->estado; i++) {
	
		r[i].inicio = g[i].inicio;
		r[i].aceitacao = g[i].aceitacao;
	
		No* n = g[i].comeco;
	
		while(n) {
			adicionarLimite(r, n->estado, i, n->simbolo);
			n = n->prox;
		}
	
		if(g[i].aceitacao) {
			adicionarLimite(r, g->estado, i, 0);
		}
	
	}
	
	return r;
}

//Metodo para remover toods os estados inuteis
void estadosInuteis(Grafo** g) {
	
	Grafo* r = inverso(*g);
	
	dfs(r, r->estado-1); int i;
	
	for(i = 0; i < r->estado; i++) {
	
		if(!r[i].finalizado){
			*g = removerEstado(*g, i);
		} 
	}
	
	iniciaFinalizado(*g);
	
	iniciaVisitado(*g);
}

// Metodo para remover todos os estados equivalentes
Grafo* equivalente(Grafo* g, int simbolos) {
	
	bool table[g->estado][g->estado];
	
	int i; int j; int k;


	for(i = 0; i < g->estado; i++) {
		
		for(j = 0; j < g->estado; j++) {
			
			if((g[i].aceitacao && g[j].aceitacao) || (!g[i].aceitacao && !g[j].aceitacao)) {
				table[i][j] = true;
			} else {
				table[i][j] = false;
			}
		
		}
	}

	for(i = 0; i < g->estado; i++) {
		
		for(j = 0; j < g->estado; j++) {
			
			if(table[i][j]) {
				
				for(k = 0; k < simbolos; k++) {
					
					int q1 = pesquisar(g, i, k);
					int q2 = pesquisar(g, j, k);
					
					if((q1 == -1 && q2 != -1) || (q1 != -1 && q2 == -1)) {
						table[i][j] = false;
					}
				}
			}
		}
	}

	
	int count = 0;
	
	while(true) {
		
		count = 0;
		
		for(i = 0; i < g->estado; i++) {
			
			for(j = 0; j < g->estado; j++) {
				
				if(table[i][j]) {
					
					for(k = 0; k < simbolos; k++) {
						
						int q1 = pesquisar(g, i, k);
						int q2 = pesquisar(g, j, k);
						
						if(q1 != -1 && q2 != -1 && !table[q1][q2]) {
							table[i][j] = false; count++;
						}
					}
				}
			}
		}
		
		if(count == 0){
			break;
		} 
	}

	int rep[g->estado];
	
	for(i = 0; i < g->estado; i++) {
		rep[i] = -1;
	}

	count = 0;
	
	while(true) {
		
		int times = 0;
		
		for(i = 0; i < g->estado; i++) {
			
			if(rep[i] == -1) {
				
				count++;
				
				rep[i] = count -1;
				
				for(j = 0; j < g->estado; j++) {
					
					if(table[i][j]) rep[j] = rep[i];
					times++;
				}
			}
		}
		if(times == 0){
			break;
		} 
	}

	Grafo* m = novoGrafo(count);
	
	for(i = 0; i < g->estado; i++) {
		
		if(g[i].inicio) m[rep[i]].inicio = true;
		
		if(g[i].aceitacao) m[rep[i]].aceitacao = true;
		
		No* n = g[i].comeco;
		
		while(n) {
			adicionarLimite(m, rep[i], rep[n->estado], n->simbolo);
			n = n->prox;
		}
	}

	return m;
}

//Metodo para escrever o novo AFD gerado
void escreverAFD(Grafo* g, int simbolos, FILE* file) {
	
	int i; int inicio = 0;
	
	for(i = 0; i < g->estado; i++) {
		if(g[i].inicio) inicio = i;
	}
	
	fprintf(file, "%d ", g->estado);
	fprintf(file, "%d ", simbolos);
	fprintf(file, "%d\n", inicio);
	
	for(i = 0; i < g->estado; i++) {
		fprintf(file, "%d ", g[i].aceitacao);
	}

	int j;
	
	for(i = 0; i < g->estado; i++) {
		fprintf(file, "\n");
		for(j = 0; j < simbolos; j++) {
			fprintf(file, "%d ", pesquisar(g, i, j));
		}
	}

	fprintf(file, "\n");
}


